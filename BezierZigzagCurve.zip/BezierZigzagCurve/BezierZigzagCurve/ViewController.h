//
//  ViewController.h
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SnakeCurveView.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *topView;
@property (weak, nonatomic) IBOutlet SnakeCurveView *snakeView;
- (IBAction)drawPath;
@property (strong, nonatomic) NSMutableArray *pointsArray;
@property (strong, nonatomic) NSMutableArray *timeArray;
@property (strong, nonatomic) NSMutableArray *centresArray;
@property UIView *dot;

@end

