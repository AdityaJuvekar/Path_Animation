//
//  ViewController.m
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _snakeView.delegate = self;
}

-(void)setTimeArray:(NSMutableArray *)timeArray {
    _timeArray = timeArray;
}

-(void)setPointsArray:(NSMutableArray *)pointsArray {
    _pointsArray = pointsArray;
    [self creatDotsAtPointsInPointsArray];
}

-(void)setCentresArray:(NSMutableArray *)centresArray {
    _centresArray = centresArray;
}

- (IBAction)drawPath {
    if (_snakeView.draw) {
        _snakeView.draw = false;
        
    } else {
        _snakeView.draw = true;
    }
    _snakeView.numberOfNodes = 6;
    _snakeView.padding = 80;
    _snakeView.animationDuration = 6;
    _snakeView.pathWidth = 4;
    _snakeView.segmentSeparation = .3;
    _snakeView.segmentLength = 10;
    _snakeView.pathColor = [UIColor magentaColor];
    _snakeView.drawEndTail = NO;
    [_snakeView setNeedsDisplayInRect:_snakeView.frame];
}

-(void)creatDotsAtPointsInPointsArray {
    for (int i=0; i<_pointsArray.count; i++) {
        [self performSelector:@selector(createDotAtPoint:) withObject:_pointsArray[i] afterDelay:[_timeArray[i] floatValue]];
    }
}

-(void)createDotAtPoint:(NSValue*)point {
    CGPoint location = point.CGPointValue;
    _dot = [[UIView alloc] initWithFrame:CGRectMake(location.x-5, location.y-5, 10, 10)];
    [_dot setBackgroundColor:[UIColor greenColor]];
    [_topView addSubview:_dot];
    _dot.layer.cornerRadius = 5;
}


@end
