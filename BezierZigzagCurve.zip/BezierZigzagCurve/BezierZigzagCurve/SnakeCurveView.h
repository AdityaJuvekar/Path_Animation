//
//  SnakeCurveView.h
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SnakeCurveView : UIView

@property BOOL draw;

@property int numberOfNodes;
@property float animationDuration;

@property float padding;
@property float segmentLength;
@property float pathWidth;
@property float segmentSeparation;
@property UIColor *pathColor;

@property BOOL drawEndTail;

@property NSMutableArray *pointsArray;
@property NSMutableArray *timeArray;
@property NSMutableArray *centresArray;

@property (weak) id delegate;

@end
